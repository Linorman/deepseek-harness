# Agent Note: 单一 harness home 解析器

Status: implemented

[English](2026-07-24-single-harness-home-resolver.md) | 中文

## 问题

对于"Clocky 用户数据存放在哪里"，harness 里存在两套互不一致的约定：

- `@clocky/clocky-home` 按 `configured ?? $CLOCKY_HOME ?? ~/.clocky` 解析。
- `@clocky/clocky-home-paths` 又提供了**第二个** `resolveClockyHome`，优先级相同但额外做了波浪号展开——它几乎是 `clocky-home` 的重复实现，却没有任何门禁发现，因为两者分属不同的包，而且早已漂移（只有一个会展开波浪号）。

同一条横切事实有两个解析器，意味着不存在单一的 home 策略。

## 决策

由一个解析器统一掌管 harness home，落在 `@clocky/clocky-home-paths`，采用单一根目录：

```
explicit configured path  >  $CLOCKY_HOME  >  ~/.clocky
```

空或仅含空白的 `$CLOCKY_HOME` 被当作未设置处理；否则，`resolve('')` 会悄悄把 home 落在当前工作目录。harness 把所有用户数据都放在同一个根目录下；不存在 XDG 的 config/data/cache 拆分。`clockyHomePath(...segments)` 将部署负责的子路径拼接到该根目录下，`clocky-app-boot` 在挂载条目前向 Loader `!!js` 配置表达式暴露它，因此出厂组合无需复制解析器即可派生 `sessions` 和 `storages`。`clockyHomeDisplay()` 为面向用户的路径以符号形式命名已解析的根目录——默认 home 显示为 `~/.clocky`，任何已配置的 home 显示为 `$CLOCKY_HOME`——这样用户全局的 `AGENTS.md` 标签就绝不会泄露机器上的绝对路径。它取代了 agent-instructions 中自定义的「默认值 vs `$CLOCKY_HOME`」判断。

`@clocky/clocky-home` 被删除。它的三个引用方（`clocky-tool-bash`、`clocky-skill-filesystem`、`clocky-agent-spine-demo`）从 `clocky-home-paths` 导入 `resolveClockyHome`。

`clocky-telemetry` 及其独立 home 策略已随 [SDK 项目工具链移除](../simplification/2026-08-11-remove-sdk-project-toolchain.zh.md)一并消失，因此该解析器是唯一的 home 策略。

## 备选方案

**保留两份 `resolveClockyHome` 副本。** 它们早已漂移（一个展开波浪号，一个不展开），并把同一条横切事实编码了两遍。`util/` 层的意义正是在于合并，重复的解析器是一个潜在的分歧 bug。

**采用 XDG（遵从 `$XDG_CONFIG_HOME`，或把 config/data/cache 拆分到各自的目录树）。** 经过考虑后放弃，转而采用一个显而易见的根目录。单一的 `$CLOCKY_HOME || ~/.clocky` 基准事实与 `~/.claude` / `~/.aws` 一致，无需对每个 `~/.clocky` 消费方按类别重新归类，也不留下任何需要协调的解析器不对称。

## 影响

- 单一 home 事实，单一解析器。`clocky-home-paths` 是唯一归属方；`util/` 组失去了 `home` 包。
